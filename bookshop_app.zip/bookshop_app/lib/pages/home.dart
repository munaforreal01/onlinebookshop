import 'package:flutter/material.dart';
import 'package:salomon_bottom_bar/salomon_bottom_bar.dart';
import 'Order.dart';
import 'home.dart';
import 'profile.dart';

class BottomNav extends StatefulWidget {
  final int initialPageIndex;
  final String? initialOrderBookTitle;

  const BottomNav({
    super.key,
    this.initialPageIndex = 0,
    this.initialOrderBookTitle,
  });

  @override
  BottomNavState createState() => BottomNavState();
}

class BottomNavState extends State<BottomNav> {
  int _selectedIndex = 0;
  late final PageController _pageController;
  final ValueNotifier<String?> newOrderNotifier = ValueNotifier(null);

  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.initialPageIndex;
    _pageController = PageController(initialPage: _selectedIndex);

    _pages = [
      const Home(),
      Order(initialItem: widget.initialOrderBookTitle), // Pass initial item here
      const Profile(),
    ];

    // If an initial book title is provided, set it in the notifier
    if (widget.initialOrderBookTitle != null) {
      newOrderNotifier.value = widget.initialOrderBookTitle;
    }
  }

  void navigateToOrderPage(String bookTitle) {
    newOrderNotifier.value = bookTitle; // Notify the Order page
    setState(() {
      _selectedIndex = 1;
      _pageController.jumpToPage(1);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: SalomonBottomBar(
          currentIndex: _selectedIndex,
          onTap: (index) {
            setState(() {
              _selectedIndex = index;
              _pageController.jumpToPage(index);
            });
          },
          items: [
            SalomonBottomBarItem(
              icon: const Icon(Icons.home_outlined),
              title: const Text("Home"),
              selectedColor: const Color(0xFF4A64A8),
              unselectedColor: Colors.grey[600],
            ),
            SalomonBottomBarItem(
              icon: const Icon(Icons.shopping_bag_outlined),
              title: const Text("Order"),
              selectedColor: const Color(0xFF4A64A8),
              unselectedColor: Colors.grey[600],
            ),
            SalomonBottomBarItem(
              icon: const Icon(Icons.person_outline),
              title: const Text("Profile"),
              selectedColor: const Color(0xFF4A64A8),
              unselectedColor: Colors.grey[600],
            ),
          ],
        ),
        body: PageView(
            controller: _pageController,
            onPageChanged: (index) {
              setState(() {
                _selectedIndex = index;
              });
            },
            children: _pages,
             ),
            );
      }
}